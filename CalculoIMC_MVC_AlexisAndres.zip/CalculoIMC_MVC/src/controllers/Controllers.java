/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;
import models.Models;
import views.Views;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author Andy
 */
public class Controllers implements ActionListener {
    
    Models modelMessage;
    Views viewMessage;

    public Controllers(Models ModelsIMC, Views ViewsIMC) {
        this.modelMessage = ModelsIMC;
        this.viewMessage = ViewsIMC;
        
        this.viewMessage.jb_calcular.addActionListener(this);
        initComponents();
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == viewMessage.jb_calcular) {
            jb_calcular_action_performed();
        }
    }
    
    public void jb_calcular_action_performed() {
//        modelMessage.setName(viewMessage.jtf_name.getText());
//        viewMessage.jl_imc.setText("Hello " + modelMessage.getName());

        float peso = 0.0f;
        float estatura = 0.0f;
        float imc = 0.0f;

        boolean verificacion;
        boolean verificacion2;

        try {
            Float.parseFloat(this.viewMessage.jtf_peso.getText());
            verificacion = true;
        }
        catch (NumberFormatException error) {
            verificacion = false;
        }

        try {
            Float.parseFloat(this.viewMessage.jtf_estatura.getText());
            verificacion2 = true;
        }
        catch (NumberFormatException error2) {
            verificacion2 = false;
        }

        if (verificacion == true && verificacion2 == true) {

            peso = Float.parseFloat(this.viewMessage.jtf_peso.getText());
            estatura = Float.parseFloat(this.viewMessage.jtf_estatura.getText());
            imc = peso / (estatura * estatura);

            if ( peso > 0 && estatura > 0 && estatura <= 3) {
                if (imc < 18.5) {
//                    JOptionPane.showMessageDialog(this, "Su IMC es: " + imc + " (Peso bajo).");
                    
                    viewMessage.jl_imc.setText("Su IMC es: " + imc);
                    viewMessage.jl_resultado.setText("Usted tiene Peso Bajo");
                }

                else if (imc >= 18.5 && imc < 25) {
//                    JOptionPane.showMessageDialog(this, "Su IMC es: " + imc + " (Peso normal).");
                    
                    viewMessage.jl_imc.setText("Su IMC es: " + imc);
                    viewMessage.jl_resultado.setText("Usted tiene Peso Normal");
                }

                else if (imc >= 25 && imc < 30) {
//                    JOptionPane.showMessageDialog(this, "Su IMC es: " + imc + " (Sobrepeso).");
                    
                    viewMessage.jl_imc.setText("Su IMC es: " + imc);
                    viewMessage.jl_resultado.setText("Usted tiene Sobrepeso");
                }

                else if (imc >= 30) {
//                    JOptionPane.showMessageDialog(this, "Su IMC es :" + imc + " (Obesidad).");
                    
                    viewMessage.jl_imc.setText("Su IMC es: " + imc);
                    viewMessage.jl_resultado.setText("Usted tiene Obesidad");
                }
            }
            else if (estatura > 3) {
//                JOptionPane.showMessageDialog(this, "Dato invalido. La estatura debe introducirse en metros");
            }
            else {
//                JOptionPane.showMessageDialog(this, "Introduce unicamente numeros positivos.");
            }
        }

        else if (verificacion == false || verificacion2 == false) {
//            JOptionPane.showMessageDialog(this, "Dato invalido. Introduce solamente numeros");
        }
    }
    
    public void initComponents() {
        viewMessage.setVisible(true);
//        viewMessage.jtf_name.setText(modelMessage.getName());
    }
}
