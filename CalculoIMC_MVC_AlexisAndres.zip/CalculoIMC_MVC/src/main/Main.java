/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import models.Models;
import views.Views;
import controllers.Controllers;

/**
 *
 * @author Andy
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Models modelMessage = new Models();
        Views viewMessage = new Views();
        Controllers controllerMessage = new Controllers(modelMessage, viewMessage);
    }
    
}
